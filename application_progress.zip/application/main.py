from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)


class Vacancy:
    def __init__(self, position, department, requirements):
        self.position = position
        self.department = department
        self.requirements = requirements
        self.applications = []

    def apply(self, student):
        self.applications.append({
            'student': student,
            'status': 'Pending'
        })

    def update_application_status(self, student_email, new_status):
        for application in self.applications:
            if application['student'].email == student_email:
                application['status'] = new_status
                return True
        return False


class Student:
    def __init__(self, name, email, qualifications):
        self.name = name
        self.email = email
        self.qualifications = qualifications


university_name = "Durban University Of Technology"

# Define three vacancies
vacancies = [
    Vacancy("Tutor", "Computer Science", "Ph.D. in Computer Science"),
    Vacancy("Teacher Assistant for App dev", "Information Technology", "Bachelor's degree in Computer Science"),
    Vacancy("Marketing Tutor", "Marketing", "Bachelor's degree in Marketing or related field")
]


@app.route('/')
def index():
    vacancy_indices = list(range(len(vacancies)))
    return render_template('application_form.html', university_name=university_name,
                           vacancies=vacancies, vacancy_indices=vacancy_indices)


@app.route('/apply', methods=['POST'])
def apply():
    name = request.form['name']
    email = request.form['email']
    qualifications = request.form['qualifications']
    student = Student(name, email, qualifications)

    vacancy_index = int(request.form['vacancy'])
    vacancies[vacancy_index].apply(student)

    return redirect(url_for('application_status', email=email))


@app.route('/application_status/<string:email>')
def application_status(email):
    user_applications = []
    for vacancy in vacancies:
        for application in vacancy.applications:
            if application['student'].email == email:
                user_applications.append({
                    'position': vacancy.position,
                    'department': vacancy.department,
                    'name': application['student'].name,
                    'email': application['student'].email,
                    'qualifications': application['student'].qualifications,
                    'status': application['status'],
                })
                break
    return render_template('application_status.html', university_name=university_name,
                           vacancies=vacancies, user_applications=user_applications)


@app.route('/update_status', methods=['POST'])
def update_status():
    student_email = request.form['email']
    new_status = request.form['status']
    success = False
    for vacancy in vacancies:
        if vacancy.update_application_status(student_email, new_status):
            success = True
            break
    if success:
        return redirect(url_for('application_status'))
    else:
        return "Error: Application not found."

                 
if __name__ == '__main__':
    app.run(debug=True)
